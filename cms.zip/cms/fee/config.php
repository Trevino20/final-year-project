<?php
$conn = mysqli_connect("localhost","root","","cms")or die("connection lost");
?>