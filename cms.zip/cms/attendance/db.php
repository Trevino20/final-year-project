<?php
$con = mysqli_connect("localhost","root","","cms")or die("connection lost");
?>

<!-- $result=mysqli_query($con,"select distinct date  from attendance");
$serialnumber=0;

while($row=mysqli_fetch_array($result))
{
$serialnumber++;
?>
<tr>
<td> <?php  //echo //$serialnumber; ?> </td>
<td> <?php  //echo //$row['date']; ?> 
</td> -->